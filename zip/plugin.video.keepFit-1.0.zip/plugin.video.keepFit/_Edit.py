import xbmcaddon

MainBase = 'https://goo.gl/ty7RxW'
addon = xbmcaddon.Addon('plugin.video.keepFit')